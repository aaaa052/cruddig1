# CRUD_Application_Node
In this project, we are going to create node CRUD application with express and mongodb.
```
npm install
```

Then Create config.env file and create PORT and MONGO_URI Variable and specify Value.
That's it. You are ready to go. To execute this project just type
```
npm start
```
this is my Nodejs Project
this CRUD app that helps to some user information Create Read Update and Delete.
App use check status of user user active or not.
mainly i have use IDE vs code and use reactjs for frontend, nodejs expressjs for backend , for database mongoDB , api request of database use Postman.
first frontend page show all record of user and also show button add NEW user click on this just switch on backend page so this page show some information required fill that after submit add database and see frontend page.
  

Enjoy...!
